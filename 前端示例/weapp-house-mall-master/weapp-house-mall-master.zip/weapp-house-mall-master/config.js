var config = {

  APPID     :'McTxMpyh',
  HTTP_BASE_URL :'https://api.getweapp.com/vendor/huosu/api',
}

module.exports = config;
