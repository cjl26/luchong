var base = {}
base.url = 'https://www.xkedou.cn/addons/zjhj_pt/core/web/index.php?r=api%2Fapi/';
base.wechat_id = 71;
module.exports = base